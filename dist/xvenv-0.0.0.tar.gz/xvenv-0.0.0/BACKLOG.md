
Check
[`CHANGELOG`](https://github.com/kr-g/smog/blob/xvenv/CHANGELOG.md)
for latest ongoing, or upcoming news.


# BACKLOG

- microsoft windows support
- 


# OPEN ISSUES

refer to [issues](https://github.com/kr-g/xvenv/issues)


# LIMITATIONS

- only linux
- 

