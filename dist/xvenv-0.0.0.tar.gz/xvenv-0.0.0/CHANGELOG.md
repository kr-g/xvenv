
see [`BACKLOG`](https://github.com/kr-g/smog/blob/xvenv/BACKLOG.md)
for open development tasks and limitations.


# CHANGELOG


## version v0.0.1 - ???

- first release
- 
